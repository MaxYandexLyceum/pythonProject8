package com.benot.search;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Spinner;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;
import android.graphics.Typeface;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class PoskActivity extends  Activity {


	private String ediitt = "";
	private String ediit = "";
	private HashMap<String, Object> koo = new HashMap<>();
	private double selec = 0;
	private HashMap<String, Object> nnn = new HashMap<>();

	private ArrayList<HashMap<String, Object>> posikliss = new ArrayList<>();
	private ArrayList<String> shabloni = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();

	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView poisklist;
	private Spinner spinner1;
	private Button addbutt;
	private Button savebutt;

	private SharedPreferences pos;
	private Intent cale = new Intent();
	private AlertDialog.Builder vvv;
	private AlertDialog.Builder dialoque;
	private AlertDialog.Builder dialogue;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.posk);
		initialize(_savedInstanceState);
		initializeLogic();
	}

	private void initialize(Bundle _savedInstanceState) {

	    // объекты
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		poisklist = (ListView) findViewById(R.id.poisklist);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		addbutt = (Button) findViewById(R.id.addbutt);

		savebutt = (Button) findViewById(R.id.savebutt);

		pos = getSharedPreferences("pos", Activity.MODE_PRIVATE);
		vvv = new AlertDialog.Builder(this);
		dialoque = new AlertDialog.Builder(this);

		dialogue = new AlertDialog.Builder(this);

		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				selec = _position;
				if (0 == _position) {
					poisklist.setAdapter(new PoisklistAdapter(posikliss));
				}
				if (1 == _position) {
					lmap.clear();
					nnn = new HashMap<>();

					// сайты
					nnn.put("nazv", "Google");
					nnn.put("link", "https://www.google.ru/search?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Yandex");
					nnn.put("link", "https://yandex.ru/search/touch/?text=9nsldvGPbygh8Rfr");
					lmap.add(nnn);

					nnn = new HashMap<>();
					nnn.put("nazv", "Mail.ru");
					nnn.put("link", "https://go.mail.ru/msearch?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();

					nnn.put("nazv", "DuckDuckGo");
					nnn.put("link", "https://duckduckgo.com/?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					poisklist.setAdapter(new PoisklistAdapter(lmap));
				}
				if (2 == _position) {
					lmap.clear();
					nnn = new HashMap<>();
					nnn.put("nazv", "Google Market");
					nnn.put("link", "https://www.google.com/search?tbm=shop&q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);


					nnn = new HashMap<>();
					nnn.put("nazv", "Yandex Market");
					nnn.put("link", "https://yandex.ru/search/touch/?text=9nsldvGPbygh8Rfr");
					lmap.add(nnn);

					nnn = new HashMap<>();
					nnn.put("nazv", "E-katalog");
					nnn.put("link", "https://www.e-katalog.ru/ek-list.php?search_=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Aliexpress");

					nnn.put("link", "https://m.aliexpress.ru/wholesale/9nsldvGPbygh8Rfr.html?channel=direct&keywords=9nsldvGPbygh8Rfr");
					lmap.add(nnn);

					nnn = new HashMap<>();
					nnn.put("nazv", "Avito");
					nnn.put("link", "https://m.avito.ru/smolensk?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();


					nnn.put("nazv", "OZON");

					nnn.put("link", "https://www.ozon.ru/search/?from_global=true&text=9nsldvGPbygh8Rfr");
					lmap.add(nnn);

					poisklist.setAdapter(new PoisklistAdapter(lmap));
				}
				if (3 == _position) {
					lmap.clear();
					//  lmap.clear();
					nnn = new HashMap<>();
					nnn.put("nazv", "Youtube");
					nnn.put("link", "https://m.youtube.com/results?search_query=9nsldvGPbygh8Rfr");
					lmap.add(nnn);

					nnn = new HashMap<>();
					nnn.put("nazv", "Yandex Efir");
					nnn.put("link", "https://yandex.ru/efir?stream_active=serp&search_text=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "RuTube");
					nnn.put("link", "https://rutube.ru/newsearch/?query=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Twitch");
					nnn.put("link", "https://m.twitch.tv/search?term=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					poisklist.setAdapter(new PoisklistAdapter(lmap));
				}
				if (4 == _position) {
					lmap.clear();
					nnn = new HashMap<>();
					nnn.put("nazv", "Spotify");
					nnn.put("link", "https://open.spotify.com/search/results/9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "SoundCloud");
					nnn.put("link", "https://m.soundcloud.com/search/results?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Youtube Music");
					nnn.put("link", "https://music.youtube.com/search?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Hitmo");
					nnn.put("link", "https://ruv.hotmo.org/search?q=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					poisklist.setAdapter(new PoisklistAdapter(lmap));
				}
				if (5 == _position) {
					lmap.clear();
					nnn = new HashMap<>();
					nnn.put("nazv", "4PDA");
					nnn.put("link", "https://4pda.ru/?s=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "LOLZTEAM");
					nnn.put("link", "https://lolz.guru/search/23585540/?q=9nsldvGPbygh8Rfr&o=relevance");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "VKontakte");
					nnn.put("link", "https://m.vk.com/search?c[section]=auto&c[q]=9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Google Maps");
					nnn.put("link", "https://www.google.ru/maps/search/9nsldvGPbygh8Rfr");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Google Translate");
					nnn.put("link", "https://translate.google.com/?hl=ru&sl=ru&tl=en&text=9nsldvGPbygh8Rfr&op=translate");
					lmap.add(nnn);
					nnn = new HashMap<>();
					nnn.put("nazv", "Lamoda");
					nnn.put("link", "https://m.lamoda.ru/catalogsearch/result/?q=9nsldvGPbygh8Rfr&submit=y&gender_section=men");
					lmap.add(nnn);
					poisklist.setAdapter(new PoisklistAdapter(lmap));
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> _param1) {

			}
		});

		addbutt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {

				vvv.setTitle("Добавить систему");
				vvv.setMessage("Нажмите на кнопку, чтобы скопировать код, вставьте его в поиск в своей системе, выполните поиск и скопируйте ссылку. После чего введите полученную ссылку в следующее окно");
				vvv.setPositiveButton("Скопировать код", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "9nsldvGPbygh8Rfr"));
						wareUtil.showMessage(getApplicationContext(), "Код скопирован");
						_input_dialogue("", "", addbutt);
					}
				});
				vvv.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {

					}
				});
				vvv.create().show();
			}
		});

		savebutt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {

				pos.edit().putString("joo", new Gson().toJson(posikliss)).commit();
				wareUtil.showMessage(getApplicationContext(), "Сохранено");
				cale.setClass(getApplicationContext(), MainActivity.class);
				startActivity(cale);
			}
		});
	}

	@SuppressLint("WrongConstant")
    private void initializeLogic() {
		addbutt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ftb.ttf"), 1);
		savebutt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ftb.ttf"), 1);
		posikliss = new Gson().fromJson(pos.getString("joo", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		shabloni.add("Мои системы");
		shabloni.add("Поисковые системы");
		shabloni.add("Товары");
		shabloni.add("Видео");
		shabloni.add("Музыка");
		shabloni.add("Прочее");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, shabloni));
		poisklist.setAdapter(new PoisklistAdapter(posikliss));
	}

	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {

		super.onActivityResult(_requestCode, _resultCode, _data);

		switch (_requestCode) {

			default:
			break;
		}
	}

	@Override
	public void onBackPressed() {
		vvv.setTitle("Внимание");
		vvv.setMessage("При выходе из управления системами несохранённые данные потеряются. Продолжить? ");
		vvv.setPositiveButton("Ок", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				cale.setClass(getApplicationContext(), MainActivity.class);
				startActivity(cale);
			}
		});
		vvv.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {

			}
		});
		vvv.create().show();
	}
	public void _input_dialogue (final String _title, final String _msg, final TextView _text) {
		dialoque.setTitle("Добавить систему");
		dialoque.setMessage("Введите полученную ссылку");
		final EditText edittext2= new EditText(PoskActivity.this);

		LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

		edittext2.setLayoutParams(lpar);
		edittext2.setHint("Полученная ссылка");
		dialoque.setView(edittext2);


		dialoque.setPositiveButton("Добавить", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				ediit = edittext2.getText().toString();
				koo = new HashMap<>();
				koo.put("link", ediit);
				dialogue.setTitle("Добавить систему");
				dialogue.setMessage("Введите название системы");
				final EditText edittext1= new EditText(PoskActivity.this);

				LinearLayout.LayoutParams lpard = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

				edittext1.setLayoutParams(lpard);
				edittext1.setHint("Название системы");
				dialogue.setView(edittext1);


				dialogue.setPositiveButton("Добавить", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						ediitt = edittext1.getText().toString();
						koo.put("nazv", ediitt);
						posikliss.add(koo);
						((BaseAdapter)poisklist.getAdapter()).notifyDataSetChanged();
						wareUtil.showMessage(getApplicationContext(), "Успешно добавлено");
						spinner1.setSelection((int)(0));
						selec = 0;
					}
				});
				dialogue.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {

					}
				});
				dialogue.create().show();
			}
		});
		dialoque.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {

			}
		});
		dialoque.create().show();
	}


	public class PoisklistAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public PoisklistAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}

		@Override
		public int getCount() {
			return _data.size();
		}

		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}

		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cust, null);
			}

			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final TextView poiskname = (TextView) _view.findViewById(R.id.poiskname);
			final Button delete = (Button) _view.findViewById(R.id.delete);

			if (selec == 0) {
				delete.setText("Удалить");
				poiskname.setText(posikliss.get((int)_position).get("nazv").toString());
				delete.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						posikliss.remove((int)(_position));
						wareUtil.showMessage(getApplicationContext(), "Удалено");
						notifyDataSetChanged();
					}
				});
			}
			else {
				delete.setText("Добавить");
				poiskname.setText(lmap.get((int)_position).get("nazv").toString());
				delete.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						 nnn = new HashMap<>();
						nnn = lmap.get((int)_position);
						posikliss.add(nnn);
						wareUtil.showMessage(getApplicationContext(), "Добавлено");
						notifyDataSetChanged();
					}
				});
			}

			return _view;
		}
	}


	@Deprecated

	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}

	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}



	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}

	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();


		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}

}
